package com.example.autosure.app;

public interface AsyncResponse {
    void processFinish(String output);
}
