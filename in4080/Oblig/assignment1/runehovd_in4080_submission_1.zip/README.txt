The reason the Exercises are also in HTML is because jupyter returned with 500 - internal server error when trying to download as a PDF. Hope that is OK.
